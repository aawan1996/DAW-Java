import java.io.*;

interface Precio {
	int A=100;
	double B=50.3;
	double C=150.50;

	double calcularPrecio(char codigo);


}